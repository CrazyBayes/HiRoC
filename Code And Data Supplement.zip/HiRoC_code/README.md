<div align="center">

# RLinf-HRC

### Hierarchical Reinforcement Learning for Vision-Language-Action Models

[![License](https://img.shields.io/badge/license-Apache--2.0-blue.svg)](LICENSE)
[![Python](https://img.shields.io/badge/python-3.10--3.11-blue.svg)](pyproject.toml)
[![Built on RLinf](https://img.shields.io/badge/built%20on-RLinf-6f42c1.svg)](https://github.com/RLinf/RLinf)

</div>

RLinf-HRC is a research fork of [RLinf](https://github.com/RLinf/RLinf) for
hierarchical reinforcement learning in embodied agents. It adds a
**Hierarchical RL Controller (HRC)** that combines a frozen vision-language
planner with a trainable vision-language-action policy:

- **High-level planner:** Qwen2.5-VL generates the next language subgoal and
  relevant image-space object locations.
- **Low-level controller:** OpenVLA-OFT predicts action chunks conditioned on
  the current subgoal.
- **RL objective:** an HRC-aware GRPO path computes task- and subtask-level
  advantages and combines them with weights derived from the number of unique
  subgoals observed in each rollout.
- **Environment:** the included HRC experiments target the LIBERO benchmark
  and support vectorized, multi-environment planning.

This repository retains the distributed training infrastructure, FSDP actor,
Hugging Face rollout worker, Hydra configuration system, logging, checkpointing,
and simulator integrations provided by RLinf. This README focuses on the HRC
extension; refer to the [upstream documentation](https://rlinf.readthedocs.io/en/latest/)
for the rest of RLinf.

> [!IMPORTANT]
> This is experimental research code. The HRC training path in this fork is
> designed around **LIBERO + OpenVLA-OFT + GRPO**. The example configurations
> contain author-local checkpoint and resume paths; override or replace them
> before running an experiment.

## Architecture

```mermaid
flowchart LR
    O["LIBERO observation<br/>RGB image + task instruction"] --> P["Qwen2.5-VL planner<br/>FastAPI + vLLM service"]
    P -->|"subgoal + object coordinates"| H["Per-environment<br/>HRC state"]
    H --> V["OpenVLA-OFT executor<br/>trainable with FSDP"]
    O --> V
    V -->|"action chunk"| E["LIBERO environment"]
    E -->|"next observation + reward"| O
    E --> R["Rollout buffer<br/>task rewards + subtask metadata"]
    R --> G["Task/subtask GRPO advantages"]
    G --> M["Adaptive advantage mixing"]
    M --> V
```

The planner runs as a separate service and is not part of the FSDP module. This
keeps it frozen, avoids duplicating the VLM across actor workers, and allows
batched planning for vectorized environments. Each environment keeps an
independent subgoal, history, replan counter, target location, and object box.

The current actor loss combines the two advantage streams as

```text
A = ((K + L) / L) * A_task + (K / (K + L)) * A_subtask
```

where `K` is the average number of unique subgoals detected per trajectory and
`L = 512`. If no subgoal metadata is available, training falls back to the
task-level advantage. In the current rollout implementation, the subtask reward
stream is derived from final task success and broadcast across the trajectory;
subgoal boundaries determine `K` and are kept out of tensor minibatches.

## What This Fork Adds

- `HRCModel`, which uses Qwen2.5-VL planning and OpenVLA-OFT action execution.
- Per-environment hierarchical state and periodic replanning.
- Single-request and batched HTTP planner clients.
- A FastAPI/vLLM planner server for Qwen2.5-VL.
- Subtask rewards and subgoal-boundary metadata in embodied rollout buffers.
- Task- and subtask-level GRPO advantage calculation.
- Adaptive advantage mixing in the clipped actor objective.
- FSDP and rollout-worker support for `model_name: hrc`.
- More robust LIBERO subprocess error reporting and EGL device assignment.
- HRC configurations for LIBERO-10, LIBERO-Spatial, LIBERO-Object, and
  LIBERO-Goal.

## Repository Layout

```text
rlinf/
├── algorithms/
│   ├── advantages.py              # task/subtask GRPO advantages
│   ├── losses.py                  # adaptive advantage mixing
│   └── utils.py                   # HRC tensor preprocessing
├── data/io_struct.py              # HRC rollout fields
├── envs/libero/                   # LIBERO vector environments
├── models/embodiment/
│   ├── hrc_model.py               # hierarchical controller
│   └── vlm_planner.py             # HTTP planner client
└── workers/
    ├── actor/fsdp_actor_worker.py  # HRC training integration
    └── rollout/hf/                 # subgoal tracking and rollout metadata

examples/embodiment/
├── vlm_server.py                  # Qwen2.5-VL planner service
├── train_embodied_agent.py
└── config/*_hrc_openvlaoft.yaml   # HRC experiment configurations
```

## Requirements

The upstream RLinf embodied stack was developed for Linux with NVIDIA GPUs,
CUDA 12.x, MuJoCo/EGL, and Python 3.10 or 3.11. The default HRC configurations
are resource intensive: they use many parallel LIBERO environments, a 7B VLA,
and a separate VLM planner. Reduce the rollout and environment sizes when using
fewer GPUs or less CPU memory.

You will need:

1. A LIBERO installation and its assets.
2. An OpenVLA-OFT checkpoint compatible with the selected LIBERO suite.
3. A Qwen2.5-VL planner checkpoint.
4. A dedicated planner process; a separate planner GPU is recommended.

The actor and planner use different Transformer/vLLM dependency stacks. Run
them in separate Python environments or containers.

## Installation

### 1. Clone the repository

```bash
git clone https://github.com/hahans/rlinf-hrc.git
cd rlinf-hrc
```

### 2. Create the OpenVLA-OFT training environment

The simplest route is the upstream RLinf embodied Docker image. For a local
installation, install [`uv`](https://docs.astral.sh/uv/) and run the provided
installer from the repository root:

```bash
python -m pip install --upgrade uv
NO_MIRROR=1 bash requirements/install.sh openvla-oft
source .venv/bin/activate
```

By default, the installer clones LIBERO into `/opt/libero`. If that location is
not writable on your machine, install LIBERO elsewhere and add it to
`PYTHONPATH`. The detailed upstream requirements are documented in the
[RLinf installation guide](https://rlinf.readthedocs.io/en/latest/rst_source/start/installation.html).

### 3. Create a separate planner environment

The planner server needs a vLLM-compatible Qwen2.5-VL environment. The relevant
versions pinned by this codebase are:

```bash
uv venv .venv-vlm --python 3.11.10
source .venv-vlm/bin/activate
uv pip install \
  "torch==2.6.0" \
  "transformers==4.51.1" \
  "vllm==0.8.5" \
  fastapi uvicorn pillow
```

Adjust the PyTorch build for your CUDA driver if necessary.

## Quick Start

### 1. Start the VLM planner

Launch the planner in the planner environment, preferably on a GPU that is not
used by the FSDP actor:

```bash
source .venv-vlm/bin/activate
export CUDA_VISIBLE_DEVICES=0

python examples/embodiment/vlm_server.py \
  --model_path /path/to/qwen2.5-vl-planner \
  --host 0.0.0.0 \
  --port 8000
```

The client uses `http://localhost:8000` by default. Set `VLM_SERVER_URL` in the
training process when the server is on another host or port. The service exposes
`POST /plan` and `POST /plan_batch`.

### 2. Configure the training process

Activate the OpenVLA-OFT environment and export the repository and LIBERO paths:

```bash
source .venv/bin/activate

export REPO_PATH="$PWD"
export EMBODIED_PATH="$REPO_PATH/examples/embodiment"
export LIBERO_REPO_PATH="/path/to/LIBERO"
export PYTHONPATH="$REPO_PATH:$LIBERO_REPO_PATH:$PYTHONPATH"
export VLM_SERVER_URL="http://127.0.0.1:8000"

export MUJOCO_GL=egl
export PYOPENGL_PLATFORM=egl
export EGL_PLATFORM=device
export HYDRA_FULL_ERROR=1
```

`RLINF_NUM_EGL_DEVICES` defaults to `8`. Set it to the number of rendering GPUs
available to the LIBERO subprocesses if your machine uses a different layout.

### 3. Run LIBERO-Goal HRC training

The following command overrides every machine-specific path in the provided
configuration and clears its example resume checkpoint:

```bash
export VLA_CKPT="/path/to/openvla-oft-libero-goal-checkpoint"
export VLM_CKPT="/path/to/qwen2.5-vl-planner"
export RUN_DIR="$REPO_PATH/logs/hrc-libero-goal"

python "$EMBODIED_PATH/train_embodied_agent.py" \
  --config-path "$EMBODIED_PATH/config" \
  --config-name libero_goal_hrc_openvlaoft \
  "runner.logger.log_path=$RUN_DIR" \
  "runner.resume_dir=null" \
  "rollout.model_dir=$VLA_CKPT" \
  "actor.checkpoint_load_path=$VLA_CKPT" \
  "actor.tokenizer.tokenizer_model=$VLA_CKPT" \
  "actor.model.vlm_model_path=$VLM_CKPT"
```

Alternatively, after making `examples/embodiment/run_embodiment.sh` portable for
your machine, launch a named configuration with:

```bash
bash examples/embodiment/run_embodiment.sh libero_goal_hrc_openvlaoft
```

Available HRC configurations are:

| Configuration | LIBERO suite |
| --- | --- |
| `libero_10_hrc_openvlaoft` | LIBERO-10 / long-horizon tasks |
| `libero_spatial_hrc_openvlaoft` | LIBERO-Spatial |
| `libero_object_hrc_openvlaoft` | LIBERO-Object |
| `libero_goal_hrc_openvlaoft` | LIBERO-Goal |

Use a suite-specific OpenVLA-OFT checkpoint and make sure `actor.model.unnorm_key`
matches the normalization statistics stored in that checkpoint.

## Important Configuration Fields

| Field | Description |
| --- | --- |
| `actor.model.model_name` | Must be `hrc` to enable hierarchical planning. |
| `actor.model.vlm_model_path` | Planner identifier retained by the model interface. The planner server actually loads the checkpoint passed to `vlm_server.py`. |
| `actor.model.max_subgoal_steps` | Number of HRC prediction calls before replanning. |
| `actor.model.num_action_chunks` | Number of low-level actions produced per policy call. |
| `algorithm.adv_type` | Use `grpo` for the HRC advantage path in this fork. |
| `algorithm.group_size` | Number of trajectories in each GRPO comparison group. |
| `algorithm.num_group_envs` | Number of rollout groups; reduce this for smaller machines. |
| `algorithm.rollout_epoch` | Number of rollout passes collected per update. |
| `runner.resume_dir` | A `global_step_<N>` directory for resuming, or `null` for a fresh run. |
| `rollout.model_dir` | Base OpenVLA-OFT checkpoint used by rollout workers. |
| `actor.checkpoint_load_path` | Base OpenVLA-OFT checkpoint used to initialize the actor. |
| `actor.tokenizer.tokenizer_model` | Tokenizer path, normally the same as the VLA checkpoint. |

The HRC YAML files currently include `algorithm.local_weight` and
`algorithm.global_weight` as experiment placeholders. The active loss does not
read these two fields; it uses the `K`/`L` adaptive formula shown above.

## Checkpoints and Evaluation

FSDP checkpoints are written under:

```text
<log_path>/<experiment_name>/checkpoints/global_step_<N>/actor/
```

To resume training, pass the `global_step_<N>` directory, not its `actor`
subdirectory:

```bash
python "$EMBODIED_PATH/train_embodied_agent.py" \
  --config-path "$EMBODIED_PATH/config" \
  --config-name libero_goal_hrc_openvlaoft \
  "runner.resume_dir=/path/to/global_step_150" \
  "rollout.model_dir=$VLA_CKPT" \
  "actor.checkpoint_load_path=$VLA_CKPT" \
  "actor.tokenizer.tokenizer_model=$VLA_CKPT" \
  "actor.model.vlm_model_path=$VLM_CKPT"
```

For standalone evaluation, first convert the distributed checkpoint to a
regular PyTorch state dictionary:

```bash
python toolkits/ckpt_convertor/convert_dcp_to_state_dict.py \
  --dcp_path /path/to/global_step_150/actor \
  --output_path /path/to/hrc_step_150.pt
```

Then keep the planner server running and launch the embodied evaluation runner:

```bash
python "$EMBODIED_PATH/eval_embodied_agent.py" \
  --config-path "$EMBODIED_PATH/config" \
  --config-name libero_goal_hrc_openvlaoft \
  "runner.logger.log_path=$REPO_PATH/logs/eval-hrc-libero-goal" \
  "runner.resume_dir=null" \
  "rollout.model_dir=$VLA_CKPT" \
  "actor.checkpoint_load_path=$VLA_CKPT" \
  "actor.tokenizer.tokenizer_model=$VLA_CKPT" \
  "actor.model.vlm_model_path=$VLM_CKPT" \
  "+actor.model.ckpt_path=/path/to/hrc_step_150.pt"
```

## Logging

The default HRC configurations use TensorBoard. To inspect a run:

```bash
tensorboard --logdir logs --port 6006
```

In addition to standard RLinf rollout and environment metrics, the HRC path logs
the following actor metrics when subtask advantages are available:

- `actor/task_adv_weight`
- `actor/subtask_adv_weight`
- `actor/avg_subtasks_K`
- `actor/policy_loss`

Training videos are controlled by `env.train.video_cfg`, and evaluation videos
by `env.eval.video_cfg`.

## Current Limitations

- The HRC implementation is currently focused on LIBERO and OpenVLA-OFT.
- The planner server has no authentication and should only be exposed on a
  trusted network.
- Planner requests encode observations as JPEG/base64 over HTTP, which adds
  latency. Batched planning reduces, but does not remove, this overhead.
- If the planner request fails, the client returns an empty plan and the
  controller falls back to the original task instruction. Monitor planner logs
  so silent fallbacks do not invalidate an experiment.
- The current subtask reward is success-derived rather than a separately learned
  or independently verified subgoal-completion reward.
- The example YAML files and launch script still contain machine-specific paths.
  Prefer Hydra overrides or update them before publishing a reproducible setup.

## Contributing

Issues and pull requests are welcome. Please keep HRC-specific changes isolated
from unrelated upstream RLinf behavior where possible, and include the exact
configuration used to reproduce training or evaluation changes. See
[CONTRIBUTING.md](CONTRIBUTING.md) for the inherited project guidelines.

## Acknowledgements

This project is built on [RLinf](https://github.com/RLinf/RLinf) and preserves
its Apache-2.0 license and source notices. We thank the RLinf authors and the
developers of OpenVLA-OFT, LIBERO, Qwen2.5-VL, vLLM, PyTorch FSDP, and the wider
open-source embodied-AI community.

If you use this repository, please cite the original RLinf and RLinf-VLA work:

```bibtex
@misc{yu2025rlinf,
  title         = {RLinf: Flexible and Efficient Large-scale Reinforcement Learning via Macro-to-Micro Flow Transformation},
  author        = {Chao Yu and Yuanqing Wang and Zhen Guo and Hao Lin and Si Xu and Hongzhi Zang and Quanlu Zhang and Yongji Wu and Chunyang Zhu and Junhao Hu and Zixiao Huang and Mingjie Wei and Yuqing Xie and Ke Yang and Bo Dai and Zhexuan Xu and Xiangyuan Wang and Xu Fu and Zhihao Liu and Kang Chen and Weilin Liu and Gang Liu and Boxun Li and Jianlei Yang and Zhi Yang and Guohao Dai and Yu Wang},
  year          = {2025},
  eprint        = {2509.15965},
  archivePrefix = {arXiv},
  primaryClass  = {cs.LG},
  url           = {https://arxiv.org/abs/2509.15965}
}

@misc{zang2025rlinfvla,
  title         = {RLinf-VLA: A Unified and Efficient Framework for VLA+RL Training},
  author        = {Hongzhi Zang and Mingjie Wei and Si Xu and Yongji Wu and Zhen Guo and Yuanqing Wang and Hao Lin and Liangzhi Shi and Yuqing Xie and Zhexuan Xu and Zhihao Liu and Kang Chen and Wenhao Tang and Quanlu Zhang and Weinan Zhang and Chao Yu and Yu Wang},
  year          = {2025},
  eprint        = {2510.06710},
  archivePrefix = {arXiv},
  primaryClass  = {cs.RO},
  url           = {https://arxiv.org/abs/2510.06710}
}
```

## License

Licensed under the [Apache License 2.0](LICENSE).
