# Copyright 2025 The RLinf Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Hierarchical RL Controller (HRC) combining VLM planning with VLA execution."""

from typing import Any, Dict, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
from PIL import Image
from prismatic.extern.hf.configuration_prismatic import (
    OpenVLAConfig as OpenVLAOFTConfig,
)

from rlinf.models.embodiment.openvla_oft_action_model import OpenVLAOFTForRLActionPrediction
from rlinf.models.embodiment.vlm_planner import VLMPlanner


class HRCModel(OpenVLAOFTForRLActionPrediction):
    """
    Hierarchical RL Controller: VLM (frozen) for subgoal generation + VLA (trainable) for action execution.
    
    Architecture:
        - Upper level: VLM (Qwen2.5-VL) - generates subgoals and object locations
        - Lower level: VLA (OpenVLA-OFT) - generates actions conditioned on subgoals
        
    Modified to inherit from OpenVLAOFTForRLActionPrediction for better FSDP compatibility.
    """

    def __init__(
        self,
        config: OpenVLAOFTConfig,
        action_dim: int,
        num_action_chunks: int,
        add_value_head: bool,
        vlm_model_path: Optional[str] = None,
        device: str = "cuda",
        **kwargs
    ):
        # Initialize the VLA model (parent class)
        super().__init__(
            config=config,
            action_dim=action_dim,
            num_action_chunks=num_action_chunks,
            add_value_head=add_value_head
        )
        
        # Upper level: frozen VLM for planning
        # Store as plain Python attribute (not nn.Module) to exclude from FSDP
        # Use object.__setattr__ to bypass nn.Module's __setattr__ and avoid registration
        if vlm_model_path:
            object.__setattr__(self, '_vlm_planner', VLMPlanner(
                model_path=vlm_model_path,
                device="cpu",  # Start on CPU, load to GPU during rollout
                torch_dtype=torch.bfloat16
            ))
        else:
            # Handle case where vlm_model_path is not provided (e.g. loading VLA only)
            # or it will be set later
            pass
        
        self.device_name = device  # Avoid conflict with nn.Module.device property if it exists
        
        # Hierarchical control state (per-env; sized lazily on first batch)
        # NOTE: vectorized env rollout uses batch dimension = num_envs.
        self._env_current_subgoals = []  # list[Optional[str]]
        self._env_subgoal_histories = []  # list[list[str]]
        self._env_subgoal_step_counts = []  # list[int] (steps elapsed under current subgoal)
        self._env_current_target_coords = []  # list[Optional[Any]]
        self._env_current_obj_bboxes = []  # list[Optional[Any]]

        # Back-compat single-env aliases (env_idx=0)
        self.current_subgoal = None
        self.subgoal_history = []
        self.subgoal_step_count = 0
        self.max_subgoal_steps = getattr(config, "max_subgoal_steps", 20)
        
        # For reward computation
        self.current_target_coord = None
        self.current_obj_bbox = None
    
    @property
    def vlm_planner(self):
        """Property to access VLM planner."""
        if hasattr(self, '_vlm_planner'):
            return self._vlm_planner
        return None
        
    def reset_subgoal_state(self):
        """Reset subgoal tracking for new episode (all envs)."""
        self._env_current_subgoals = []
        self._env_subgoal_histories = []
        self._env_subgoal_step_counts = []
        self._env_current_target_coords = []
        self._env_current_obj_bboxes = []

        # Back-compat aliases
        self.current_subgoal = None
        self.subgoal_history = []
        self.subgoal_step_count = 0
        self.current_target_coord = None
        self.current_obj_bbox = None

    def reset_subgoal_state_for_env(self, env_idx: int):
        """Reset subgoal tracking for a single env in a vectorized batch."""
        if env_idx < 0:
            return
        if env_idx >= len(self._env_current_subgoals):
            return
        self._env_current_subgoals[env_idx] = None
        self._env_subgoal_histories[env_idx] = []
        self._env_subgoal_step_counts[env_idx] = 0
        self._env_current_target_coords[env_idx] = None
        self._env_current_obj_bboxes[env_idx] = None

        # Keep legacy aliases consistent for env0
        if env_idx == 0:
            self.current_subgoal = None
            self.subgoal_history = []
            self.subgoal_step_count = 0
            self.current_target_coord = None
            self.current_obj_bbox = None

    def _ensure_env_state(self, batch_size: int):
        """Ensure per-env state lists are initialized to given batch size."""
        if batch_size <= 0:
            return
        if len(self._env_current_subgoals) == batch_size:
            return
        self._env_current_subgoals = [None for _ in range(batch_size)]
        self._env_subgoal_histories = [[] for _ in range(batch_size)]
        self._env_subgoal_step_counts = [0 for _ in range(batch_size)]
        self._env_current_target_coords = [None for _ in range(batch_size)]
        self._env_current_obj_bboxes = [None for _ in range(batch_size)]

    def get_subgoal_step_count(self, env_idx: int = 0) -> int:
        if 0 <= env_idx < len(self._env_subgoal_step_counts):
            return int(self._env_subgoal_step_counts[env_idx])
        return int(self.subgoal_step_count)
        
    def should_replan(self, env_idx: int = 0) -> bool:
        """Determine if replanning is needed for a given env."""
        if 0 <= env_idx < len(self._env_current_subgoals):
            return (
                self._env_current_subgoals[env_idx] is None
                or self._env_subgoal_step_counts[env_idx] >= self.max_subgoal_steps
            )
        # Fallback (single-env / uninitialized)
        return (self.current_subgoal is None) or (self.subgoal_step_count >= self.max_subgoal_steps)
    
    def plan_subgoal(self, observation: Dict, task_description: str, env_idx: int = 0) -> Dict:
        """
        Use VLM to generate next subgoal.
        """
        if not self.vlm_planner:
            return {"subgoal": None, "rel_obj_bbox": None, "target_coord_2d": None}

        # Extract image from observation
        prev_subgoal = None
        if 0 <= env_idx < len(self._env_current_subgoals):
            prev_subgoal = self._env_current_subgoals[env_idx]
        else:
            prev_subgoal = self.current_subgoal
        if "agentview_image" in observation:
            image_np = observation["agentview_image"]
        elif "image" in observation:
            image_np = observation["image"]
        else:
            raise KeyError("No image found in observation")
            
        # Convert to PIL Image
        if isinstance(image_np, torch.Tensor):
            image_np = image_np.cpu().numpy()
        # Many envs store images normalized to [0,1]. Convert robustly to uint8 [0,255].
        try:
            import numpy as np  # local import to avoid hard dependency at module import time
        except Exception:
            np = None

        if np is not None and isinstance(image_np, np.ndarray):
            if image_np.dtype.kind == "f":
                max_val = float(np.nanmax(image_np)) if image_np.size else 0.0
                if max_val <= 1.0:
                    image_np = (image_np * 255.0).clip(0.0, 255.0)
                else:
                    image_np = image_np.clip(0.0, 255.0)
                image_np = image_np.astype("uint8")
            else:
                image_np = image_np.clip(0, 255).astype("uint8")
        else:
            # Fallback: best-effort cast
            image_np = image_np.astype("uint8")

        image = Image.fromarray(image_np)
        
        # Call VLM planner (must be on GPU)
        if 0 <= env_idx < len(self._env_subgoal_histories):
            subgoal_history = self._env_subgoal_histories[env_idx]
        else:
            subgoal_history = self.subgoal_history

        with torch.no_grad():
            plan_output = self.vlm_planner.plan(
                image=image,
                task_description=task_description,
                subgoal_history=subgoal_history
            )
        
        # Update hierarchical state
        if plan_output["subgoal"]:
            if 0 <= env_idx < len(self._env_current_subgoals):
                if prev_subgoal and prev_subgoal != plan_output["subgoal"]:
                    self._env_subgoal_histories[env_idx].append(prev_subgoal)
                # New subgoal => reset step counter (matches old behavior/meaning)
                if prev_subgoal != plan_output["subgoal"]:
                    self._env_subgoal_step_counts[env_idx] = 0
                self._env_current_subgoals[env_idx] = plan_output["subgoal"]
            else:
                # Fallback
                if prev_subgoal and prev_subgoal != plan_output["subgoal"]:
                    self.subgoal_history.append(prev_subgoal)
                if prev_subgoal != plan_output["subgoal"]:
                    self.subgoal_step_count = 0
                self.current_subgoal = plan_output["subgoal"]
            
        # Store for reward computation
        if plan_output["rel_obj_bbox"]:
            if 0 <= env_idx < len(self._env_current_obj_bboxes):
                self._env_current_obj_bboxes[env_idx] = plan_output["rel_obj_bbox"]
            else:
                self.current_obj_bbox = plan_output["rel_obj_bbox"] # First object
        if plan_output["target_coord_2d"]:
            if 0 <= env_idx < len(self._env_current_target_coords):
                self._env_current_target_coords[env_idx] = plan_output["target_coord_2d"]
            else:
                self.current_target_coord = plan_output["target_coord_2d"]

        # Keep env0 legacy aliases in sync for existing callers
        if env_idx == 0 and 0 < len(self._env_current_subgoals):
            self.current_subgoal = self._env_current_subgoals[0]
            self.subgoal_history = self._env_subgoal_histories[0]
            self.subgoal_step_count = self._env_subgoal_step_counts[0]
            self.current_target_coord = self._env_current_target_coords[0]
            self.current_obj_bbox = self._env_current_obj_bboxes[0]
            
        return plan_output
    
    def _apply_plan_output_to_env(self, env_idx: int, plan_output: Dict):
        """Apply a VLM planning output to a specific environment's hierarchical state."""
        if env_idx < 0 or env_idx >= len(self._env_current_subgoals):
            return
        
        prev_subgoal = self._env_current_subgoals[env_idx]
        new_subgoal = plan_output.get("subgoal", None)
        
        if new_subgoal:
            # If subgoal changed, archive the old one and reset step count
            if prev_subgoal and prev_subgoal != new_subgoal:
                self._env_subgoal_histories[env_idx].append(prev_subgoal)
            if prev_subgoal != new_subgoal:
                self._env_subgoal_step_counts[env_idx] = 0
            
            self._env_current_subgoals[env_idx] = new_subgoal
        
        # Update object bbox and target coordinates
        rel_obj_bbox = plan_output.get("rel_obj_bbox", None)
        if rel_obj_bbox:
            self._env_current_obj_bboxes[env_idx] = rel_obj_bbox
        
        target_coord_2d = plan_output.get("target_coord_2d", None)
        if target_coord_2d:
            self._env_current_target_coords[env_idx] = target_coord_2d
        
        # Sync env0 legacy attributes (for backward compatibility with single-env code)
        if env_idx == 0:
            self.current_subgoal = self._env_current_subgoals[0]
            self.subgoal_history = self._env_subgoal_histories[0]
            self.subgoal_step_count = self._env_subgoal_step_counts[0]
            self.current_target_coord = self._env_current_target_coords[0]
            self.current_obj_bbox = self._env_current_obj_bboxes[0]
    
    def _extract_planner_image_np(self, images: Any, env_idx: int = 0):
        """
        Extract a single image for VLM planner from possibly batched/multi-camera tensors.
        Supports:
          - [B, C, H, W]
          - [B, N, C, H, W] (takes camera 0)
          - [C, H, W]
        Returns numpy in HWC format.
        """
        img = images
        if isinstance(images, torch.Tensor):
            if images.dim() == 5:
                img = images[env_idx, 0]  # [C,H,W]
            elif images.dim() == 4:
                img = images[env_idx]  # [C,H,W]
            elif images.dim() == 3:
                img = images
            else:
                raise ValueError(f"Unsupported images tensor shape for planner: {tuple(images.shape)}")
            img = img.detach().cpu().numpy()
        else:
            # numpy / list-like
            if hasattr(images, "ndim"):
                if images.ndim == 5:
                    img = images[env_idx, 0]
                elif images.ndim == 4:
                    img = images[env_idx]
                elif images.ndim == 3:
                    img = images
            else:
                # list case: assume list over envs
                img = images[env_idx]

        # CHW -> HWC if needed
        if hasattr(img, "shape") and len(img.shape) == 3 and img.shape[0] == 3:
            img = img.transpose(1, 2, 0)
        return img
    
    def compute_dense_reward(
        self,
        observation: Dict,
        env_reward: float = 0.0,
        done: bool = False,
        env=None
        ,
        env_idx: int = 0
    ) -> float:
        """
        Compute dense reward using VLM-based geometric reasoning.
        """
        # If episode done, return sparse reward only
        # if done:
        #     return env_reward
            
        # if not self.vlm_planner:
        #     return env_reward

        # Get arm end-effector position
        arm_uv = None
        
        # Method 1: Use pre-computed 2D position from env_output
        # if "robot0_eef_pos_2d" in observation:
        #     arm_uv = observation["robot0_eef_pos_2d"]
        #     if isinstance(arm_uv, torch.Tensor):
        #         arm_uv = tuple(arm_uv.cpu().numpy())
        
        # Method 2: Use VLM planner's get_end_effector_2d_position
        if arm_uv is None and env is not None:
            try:
                pixel_coord, depth, ee_pos = self.vlm_planner.get_end_effector_2d_position(
                    env=env,
                    camera_name="agentview",
                    image_height=224,
                    image_width=224,
                    obs=observation,
                    verbose=False
                )
                if pixel_coord is not None:
                    arm_uv = tuple(pixel_coord)
            except Exception as e:
                pass
        
        # # Method 3: Approximate from 3D position if available
        # if arm_uv is None and "robot0_eef_pos" in observation:
        #     eef_pos = observation["robot0_eef_pos"]
        #     if isinstance(eef_pos, torch.Tensor):
        #         eef_pos = eef_pos.cpu().numpy()
            
        #     u = int((eef_pos[0] + 0.5) * 160 + 32)  # x -> u
        #     v = int((eef_pos[1] + 0.5) * 160 + 32)  # y -> v
        #     u = max(0, min(223, u))
        #     v = max(0, min(223, v))
        #     arm_uv = (u, v)
        
        # Method 4: Default to image center
        if arm_uv is None:
            arm_uv = (112, 112)
        
        # Compute dense reward if we have object info
        dense_reward = 0.0
        obj_bbox = None
        target_coord = None
        if 0 <= env_idx < len(self._env_current_obj_bboxes):
            obj_bbox = self._env_current_obj_bboxes[env_idx]
            target_coord = self._env_current_target_coords[env_idx]
        else:
            obj_bbox = self.current_obj_bbox
            target_coord = self.current_target_coord

        if obj_bbox is not None:
            if arm_uv == (112, 112):
                dense_reward = -0.1
            else:
                dense_reward = self.vlm_planner.compute_step_reward(
                    arm_uv=arm_uv,
                    obj_bbox=obj_bbox,
                    target_uv=target_coord,
                    w1=1.0,
                    w2=1
                )
            
        return  dense_reward
    
    def predict_action_batch(
        self,
        env_obs: Dict,
        task_description: Optional[str] = None,
        mode: str = "train",
        **kwargs
    ) -> Tuple[torch.Tensor, Dict]:
        """
        Hierarchical action prediction: VLM planning + VLA execution.
        """
        # Get batch size from env_obs
        batch_size = len(env_obs["task_descriptions"]) if "task_descriptions" in env_obs else 1
        self._ensure_env_state(batch_size)
        
        # Step 1: VLM planning - replan per env (multi-env safe)
        if batch_size > 0 and self.vlm_planner:
            # Collect all environments that need replanning
            envs_to_replan = [b for b in range(batch_size) if self.should_replan(env_idx=b)]
            # envs_to_replan = [b for b in range(batch_size)]
            if envs_to_replan:
                # Try batch planning if available (faster for multi-env)
                if hasattr(self.vlm_planner, "plan_batch"):
                    # Prepare batch inputs
                    # print('quick batch planning')
                    batch_images = []
                    batch_tasks = []
                    batch_histories = []
                    
                    for b in envs_to_replan:
                        img_b_np = self._extract_planner_image_np(env_obs["images"], env_idx=b)
                        # Convert to PIL Image (same logic as plan_subgoal)
                        if isinstance(img_b_np, torch.Tensor):
                            img_b_np = img_b_np.detach().cpu().numpy()
                        
                        # Handle 0-1 float to 0-255 uint8
                        if img_b_np.dtype.kind == "f":
                            max_val = float(np.nanmax(img_b_np)) if img_b_np.size else 0.0
                            if max_val <= 1.0:
                                img_b_np = (img_b_np * 255.0).clip(0.0, 255.0)
                            else:
                                img_b_np = img_b_np.clip(0.0, 255.0)
                            img_b_np = img_b_np.astype("uint8")
                        else:
                            img_b_np = img_b_np.clip(0, 255).astype("uint8")
                        
                        pil_img = Image.fromarray(img_b_np)
                        batch_images.append(pil_img)
                        batch_tasks.append(env_obs["task_descriptions"][b])
                        batch_histories.append(self._env_subgoal_histories[b])
                    
                    # Call batch planner (single vLLM batch inference)
                    batch_outputs = self.vlm_planner.plan_batch(
                        images=batch_images,
                        task_descriptions=batch_tasks,
                        subgoal_histories=batch_histories
                    )
                    
                    # Apply batch results to each env
                    for idx, b in enumerate(envs_to_replan):
                        plan_output = batch_outputs[idx]
                        self._apply_plan_output_to_env(b, plan_output)
                else:
                    # print('sequential slower planning')
                    # Fallback: sequential planning (slower)
                    for b in envs_to_replan:
                        task_b = env_obs["task_descriptions"][b]
                        img_b = self._extract_planner_image_np(env_obs["images"], env_idx=b)
                        self.plan_subgoal(
                            observation={"agentview_image": img_b, "image": img_b},
                            task_description=task_b,
                            env_idx=b,
                        )
            
        # Step 2: Augment task descriptions with subgoal for VLA
        modified_task_descriptions = []

        # for b in range(batch_size):
        #     orig_task = env_obs["task_descriptions"][b]
        #     subgoal_b = self._env_current_subgoals[b] if b < len(self._env_current_subgoals) else None
        #     if subgoal_b:
        #         subgoal_clean = subgoal_b.strip()
        #         # 判断是否以 Place / Move 开头（忽略大小写）
        #         if not subgoal_clean.lower().startswith(("place", "move")):
        #             # 从原始任务中提取 "and" 之前的部分
        #             if " and " in orig_task.lower():
        #                 # 找到第一个 and 的位置（不区分大小写）
        #                 split_idx = orig_task.lower().find(" and ")
        #                 first_part = orig_task[:split_idx].strip()
        #             else:
        #                 # 如果没有 and，就直接用原任务
        #                 first_part = orig_task.strip()
        #             modified_task_descriptions.append(first_part)
        #         else:
        #             modified_task_descriptions.append(subgoal_clean)
        #     else:
        #         modified_task_descriptions.append(orig_task)
        # modified_task_descriptions = []
        for b in range(batch_size):
            orig_task = env_obs["task_descriptions"][b]
            subgoal_b = self._env_current_subgoals[b] if b < len(self._env_current_subgoals) else None
            subgoal_clean = str(subgoal_b).strip() if subgoal_b else ""
            if subgoal_clean:
                modified_task_descriptions.append(subgoal_clean)
            else:
                modified_task_descriptions.append(orig_task)
        # print(f"modified_task_descriptions: {modified_task_descriptions}")
        # Step 3: Create modified env_obs for VLA with augmented tasks
        vla_env_obs = {
            "images": env_obs["images"],
            "states": env_obs["states"],
            "task_descriptions": modified_task_descriptions,
            "wrist_images": env_obs.get("wrist_images", None)
        }
        
        # Step 4: VLA generates actions (call super/parent implementation)
        actions, result = super().predict_action_batch(
            env_obs=vla_env_obs,
            **kwargs
        )

        # Step 5: advance per-env subgoal step counters
        for b in range(batch_size):
            if b < len(self._env_current_subgoals) and self._env_current_subgoals[b] is not None:
                self._env_subgoal_step_counts[b] += 1
        # Keep legacy env0 alias in sync
        if batch_size > 0 and len(self._env_subgoal_step_counts) > 0:
            self.current_subgoal = self._env_current_subgoals[0]
            self.subgoal_history = self._env_subgoal_histories[0]
            self.subgoal_step_count = self._env_subgoal_step_counts[0]
            self.current_target_coord = self._env_current_target_coords[0]
            self.current_obj_bbox = self._env_current_obj_bboxes[0]
        
        return actions, result
    
    def forward(self, *args, **kwargs) -> Dict:
        """
        Forward pass for training.
        """
        # VLM planner is a client, no need to manage gradients
        
        # Call VLA forward (parent implementation)
        return super().forward(*args, **kwargs)
    
    def train(self, mode: bool = True):
        """Set training mode (VLM always eval)."""
        super().train(mode)
        # VLM planner is a client, no need to set mode on it
        return self
    
    def eval(self):
        """Set evaluation mode."""
        super().eval()
        # VLM planner is a client, no need to set mode on it
        return self
    
    def to(self, *args, **kwargs):
        """Move model to device."""
        super().to(*args, **kwargs)
        # VLM planner is a client, no device management needed
        return self
