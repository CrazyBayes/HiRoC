# Copyright 2025 The RLinf Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""VLM Planner Client - Communicates with VLM server."""

import base64
import io
import json
import os
import re
import requests
from typing import Dict, List, Optional, Tuple
import numpy as np
from PIL import Image

class VLMPlanner:
    """
    Client for VLM-based planner service.
    Sends planning requests to a separate VLM server process.
    """

    def __init__(
        self, 
        model_path: str,  # Kept for signature compatibility
        device: str = "cuda",  # Kept for signature compatibility
        torch_dtype=None,  # Kept for signature compatibility
        server_url: Optional[str] = None
    ):
        """
        Initialize VLM planner client.
        
        Args:
            model_path: Ignored (handled by server)
            device: Ignored
            torch_dtype: Ignored
            server_url: URL of the VLM server (e.g., "http://localhost:8000"). 
                        Defaults to env var VLM_SERVER_URL or http://localhost:8000.
        """
        self.server_url = server_url or os.environ.get("VLM_SERVER_URL", "http://localhost:8000")
        self.endpoint = f"{self.server_url}/plan"
        print(f"VLMPlanner initialized as client connecting to {self.endpoint}")
        
        # Dummy attributes for compatibility with HRCModel logic
        self.on_device = True 
        
    def to(self, device):
        """No-op for client."""
        return self
        
    # def extract_coordinates(self, text: str) -> List[Tuple]:
    #     """Extract bounding box coordinates from VLM output."""
    #     pattern = r"'([^']+)',\s*(\d+),\s*(\d+),\s*(\d+),\s*(\d+)"
    #     matches = re.findall(pattern, text)
    #     return [(m[0], int(m[1]), int(m[2]), int(m[3]), int(m[4])) for m in matches]
        
    @staticmethod
    def _clean_subgoal(value) -> str:
        if value is None:
            return ""
        subgoal = str(value).strip().strip("`'\" ")
        return subgoal.rstrip(".; ")

    def extract_subgoal(self, text: str) -> str:
        """Extract next subgoal from VLM output."""
        try:
            parsed = json.loads(text)
            if isinstance(parsed, dict):
                subgoal = self._clean_subgoal(parsed.get("subgoal") or parsed.get("next_subgoal"))
                if subgoal:
                    return subgoal
        except Exception:
            pass

        patterns = [
            r'"(?:next_)?sub-?goal"\s*:\s*"([^"]+)"',
            r"'(?:next_)?sub-?goal'\s*:\s*'([^']+)'",
            r"(?:the\s+)?next\s+sub-?goal\s+is\s+(.+?)(?:\.|\n|$)",
            r"(?:next\s+)?sub-?goal\s*[:：]\s*(.+?)(?:\n|$)",
            r"(?:next\s+)?sub-?task\s*[:：]\s*(.+?)(?:\n|$)",
            r"(?:next\s+)?subtask\s*[:：]\s*(.+?)(?:\n|$)",
        ]
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
            if match:
                return self._clean_subgoal(match.group(1))
        return ""
    
    # def extract_target_coords(self, text: str) -> Optional[Tuple[int, int]]:
    #     """Extract target 2D coordinates from VLM output."""
    #     pattern = r"target[:\s]+(?:at\s+)?\(?(\d+),\s*(\d+)\)?"
    #     match = re.search(pattern, text, re.IGNORECASE)
    #     if match:
    #         return (int(match.group(1)), int(match.group(2)))
    #     return None
    
    @staticmethod
    def extract_coords(text: str):
        result = {
            "current": [],
            "target": []
        }

        # --- 1) 提取 current 部分 ---
        pattern_current_block = r"current image coordinates.*?are(.+?)(?=The target|$)"
        match_current = re.search(pattern_current_block, text, flags=re.DOTALL)
        if match_current:
            current_block = match_current.group(1)
            result["current"] = VLMPlanner.parse_items(current_block)

        # --- 2) 提取 target 部分 ---
        pattern_target_block = r"target image coordinates.*?are(.+?)(?:\.\s*$|$)"
        match_target = re.search(pattern_target_block, text, flags=re.DOTALL)
        if match_target:
            target_block = match_target.group(1)
            result["target"] = VLMPlanner.parse_items(target_block)

        return result

    @staticmethod
    def parse_items(block: str):
        """解析 'name', x1, y1, x2, y2 的所有条目"""
        pattern_item = r"'([^']+)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)"
        matches = re.findall(pattern_item, block)

        items = []
        for name, x1, y1, x2, y2 in matches:
            items.append({
                "name": name,
                "x1": int(x1),
                "y1": int(y1),
                "x2": int(x2),
                "y2": int(y2)
            })
        return items
    def plan(
        self, 
        image: Image.Image, 
        task_description: str,
        subgoal_history: Optional[List[str]] = None
    ) -> Dict:
        """
        Generate planning information by querying VLM server.
        """
        # Convert image to base64
        buffered = io.BytesIO()
        image.save(buffered, format="JPEG")
        img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
        
        payload = {
            "image_base64": img_str,
            "task_description": task_description,
            "subgoal_history": subgoal_history
        }
        
        try:
            response = requests.post(self.endpoint, json=payload)
            response.raise_for_status()
            result = response.json()
            pred_text = result.get("pred_text", "")
        except Exception as e:
            print(f"Error calling VLM server: {e}")
            # Fallback empty response to avoid crashing training
            result = {}
            pred_text = ""
        
        # Extract structured information locally
        subgoal = self._clean_subgoal(result.get("subgoal") or result.get("next_subgoal"))
        if not subgoal:
            subgoal = self.extract_subgoal(pred_text)
        # rel_obj_bbox = self.extract_coordinates(pred_text)
        # target_coord_2d = self.extract_target_coords(pred_text)
        coord = self.extract_coords(pred_text)
        rel_obj_bbox = result.get("rel_obj_bbox") or result.get("current") or coord["current"]
        target_coord_2d = result.get("target_coord_2d") or result.get("target") or coord["target"]
        return {
            "pred_text": pred_text,
            "subgoal": subgoal,
            "rel_obj_bbox": rel_obj_bbox,
            "target_coord_2d": target_coord_2d
        }
    
    def plan_batch(
        self,
        images: List[Image.Image],
        task_descriptions: List[str],
        subgoal_histories: Optional[List[List[str]]] = None
    ) -> List[Dict]:
        """
        Batch generate planning information for multiple environments.
        Uses vLLM batch inference for efficiency.
        
        Args:
            images: List of PIL images (one per environment)
            task_descriptions: List of task descriptions
            subgoal_histories: Optional list of subgoal histories (one per env)
        
        Returns:
            List of planning output dicts (same format as plan())
        """
        if not images:
            return []
        
        # Convert all images to base64
        images_b64 = []
        for image in images:
            buffered = io.BytesIO()
            image.save(buffered, format="JPEG")
            img_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
            images_b64.append(img_str)
        
        payload = {
            "images_base64": images_b64,
            "task_descriptions": task_descriptions,
            "subgoal_histories": subgoal_histories
        }
        
        try:
            batch_endpoint = f"{self.server_url}/plan_batch"
            response = requests.post(batch_endpoint, json=payload)
            response.raise_for_status()
            result = response.json()
            pred_texts = result.get("pred_texts", [])
            structured_outputs = result.get("outputs", [])
        except Exception as e:
            print(f"Error calling VLM batch server: {e}")
            # Fallback: empty responses for all
            structured_outputs = []
            pred_texts = [""] * len(images)
        if len(pred_texts) != len(images):
            pred_texts = list(pred_texts)[:len(images)] + [""] * max(0, len(images) - len(pred_texts))
        
        # Extract structured information for each prediction
        batch_results = []
        for idx, pred_text in enumerate(pred_texts):
            structured = structured_outputs[idx] if idx < len(structured_outputs) and isinstance(structured_outputs[idx], dict) else {}
            subgoal = self._clean_subgoal(structured.get("subgoal") or structured.get("next_subgoal"))
            if not subgoal:
                subgoal = self.extract_subgoal(pred_text)
            coord = self.extract_coords(pred_text)
            batch_results.append({
                "pred_text": pred_text,
                "subgoal": subgoal,
                "rel_obj_bbox": structured.get("rel_obj_bbox") or structured.get("current") or coord["current"],
                "target_coord_2d": structured.get("target_coord_2d") or structured.get("target") or coord["target"]
            })
        
        return batch_results

    def compute_step_reward(
        self,
        arm_uv: Tuple[float, float],
        obj_bbox,
        target_uv: Optional = None,
        w1: float = 1.0,
        w2: float = 1.0,
        target_close_thresh: float = 0.3
    ) -> float:
        """
        Compute dense reward based on arm position, object bbox, and target.

        Supports obj_bbox / target_uv as:
        - single tuple/list of (x1, y1, x2, y2)
        - dict with keys {x1, y1, x2, y2, name}
        - list of such dicts (first element used by default)

        Logic:
        - If no target provided: reward is based on arm→object distance.
        - If target provided:
            * If object is already close to target (<= target_close_thresh),
              use arm→object distance (encourage grasp/reach).
            * Else use object→target distance (encourage moving object toward target).
        """
        def _pick_first(item):
            if isinstance(item, list):
                return item[0] if item else None
            return item

        def _center_from_box(box):
            if box is None:
                return None
            if isinstance(box, dict):
                return ((box["x1"] + box["x2"]) / 2, (box["y1"] + box["y2"]) / 2)
            if isinstance(box, (tuple, list)) and len(box) == 4:
                x1, y1, x2, y2 = box
                return ((x1 + x2) / 2, (y1 + y2) / 2)
            return None
        
        # Object center
        primary_obj = _pick_first(obj_bbox)
        obj_center = _center_from_box(primary_obj)
        if obj_center is None:
            return 0.0
        obj_center_u, obj_center_v = obj_center

        arm_u, arm_v = arm_uv
        
        # Distance from arm to object
        d_arm_obj = np.sqrt(
            (arm_u - obj_center_u) ** 2 + (arm_v - obj_center_v) ** 2
        )
        
        # Normalize to [0, 1] range (assuming 224x224 image)
        image_diagonal = np.sqrt(224 ** 2 + 224 ** 2)
        d_arm_obj_norm = d_arm_obj / image_diagonal
        
        # Reward: closer is better (exp decay)
        reward_arm_obj = np.exp(-2.0 * d_arm_obj_norm) * w1
        
        # If target is specified
        if target_uv is not None:
            primary_target = _pick_first(target_uv)
            if isinstance(primary_target, dict) and {"x1", "x2", "y1", "y2"} <= set(primary_target.keys()):
                target_center = _center_from_box(primary_target)
            elif isinstance(primary_target, (tuple, list)) and len(primary_target) == 2:
                target_center = tuple(primary_target)
            else:
                target_center = None

            if target_center is not None:
                target_u, target_v = target_center
            d_obj_target = np.sqrt(
                (obj_center_u - target_u) ** 2 + (obj_center_v - target_v) ** 2
            )
            d_obj_target_norm = d_obj_target / image_diagonal
            
            if d_obj_target_norm <= target_close_thresh:
                    # Target already close to object: reward reaching the object
                    return float(reward_arm_obj)
            else:
                    # Target far from object: reward moving object toward target
                    reward_obj_target = np.exp(-2.0 * d_obj_target_norm) * w2
                    return float(reward_obj_target)

        # Default: no target or invalid target
        return float(reward_arm_obj)

    # ==================== Helper functions for end-effector 2D position ====================
    
    @staticmethod
    def get_camera_transform_matrix(sim, camera_name):
        """获取相机的变换矩阵"""
        camera_id = sim.model.camera_name2id(camera_name)
        camera_pos = sim.data.cam_xpos[camera_id]
        camera_mat = sim.data.cam_xmat[camera_id].reshape(3, 3)
        return camera_pos, camera_mat

    @staticmethod
    def get_camera_intrinsics(sim, camera_name, height, width):
        """获取相机内参矩阵"""
        camera_id = sim.model.camera_name2id(camera_name)
        fovy = sim.model.cam_fovy[camera_id]
        f = height / (2 * np.tan(np.deg2rad(fovy) / 2))
        K = np.array([
            [f, 0, width / 2],
            [0, f, height / 2],
            [0, 0, 1]
        ])
        return K

    @staticmethod
    def world_to_camera_coord(world_pos, camera_pos, camera_mat):
        """将世界坐标转换为相机坐标"""
        pos_in_world = world_pos - camera_pos
        camera_coord = camera_mat.T @ pos_in_world
        camera_coord[2] = -camera_coord[2]  # 翻转Z轴
        return camera_coord

    @staticmethod
    def project_to_image(camera_coord, K):
        """将相机坐标投影到图像平面"""
        if camera_coord[2] <= 0:
            return None, None
        pixel_homogeneous = K @ camera_coord
        pixel_coord = pixel_homogeneous[:2] / pixel_homogeneous[2]
        depth = camera_coord[2]
        return pixel_coord, depth

    @staticmethod
    def get_end_effector_2d_position(
        env,
        camera_name="agentview",
        image_height=224,
        image_width=224,
        obs=None,
        verbose=False
    ):
        """获取机器人末端执行器在指定相机图像中的2D坐标"""
        try:
            # 从obs中获取末端执行器位置
            if obs is not None and "robot0_eef_pos" in obs:
                if isinstance(obs["robot0_eef_pos"], np.ndarray):
                    ee_pos = obs["robot0_eef_pos"].copy()
                else:
                    ee_pos = np.array(obs["robot0_eef_pos"])
            else:
                # Fallback: get from simulator
                if hasattr(env, 'sim') and hasattr(env, 'robots') and len(env.robots) > 0:
                    ee_site_id = env.robots[0].eef_site_id
                    ee_pos = env.sim.data.site_xpos[ee_site_id].copy()
                else:
                    if verbose:
                        print("Warning: Cannot access env.sim or env.robots")
                    return None, None, None
            
            # 获取相机参数
            if not hasattr(env, 'sim'):
                if verbose:
                    print("Warning: env does not have 'sim' attribute")
                return None, None, ee_pos
                
            camera_pos, camera_mat = VLMPlanner.get_camera_transform_matrix(env.sim, camera_name)
            K = VLMPlanner.get_camera_intrinsics(env.sim, camera_name, image_height, image_width)
            
            # 转换到相机坐标系
            camera_coord = VLMPlanner.world_to_camera_coord(ee_pos, camera_pos, camera_mat)
            
            # 投影到图像平面
            pixel_coord, depth = VLMPlanner.project_to_image(camera_coord, K)
            
            if verbose and pixel_coord is not None:
                print(f"End-effector 3D: {ee_pos}, 2D: ({pixel_coord[0]:.1f}, {pixel_coord[1]:.1f}), depth: {depth:.3f}")
            
            return pixel_coord, depth, ee_pos
            
        except Exception as e:
            if verbose:
                print(f"Error in get_end_effector_2d_position: {e}")
            return None, None, None
