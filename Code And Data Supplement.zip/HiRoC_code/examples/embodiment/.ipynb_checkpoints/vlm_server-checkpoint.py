
import argparse
import base64
import io
import uvicorn
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import torch
from PIL import Image
from transformers import Qwen2_5_VLForConditionalGeneration, Qwen2_5_VLProcessor
from vllm import LLM, SamplingParams
app = FastAPI()

# Global model and processor
model = None
processor = None
device = "cuda" if torch.cuda.is_available() else "cpu"

class PlanRequest(BaseModel):
    image_base64: str
    task_description: str
    subgoal_history: Optional[List[str]] = None

class PlanResponse(BaseModel):
    pred_text: str

class PlanBatchRequest(BaseModel):
    images_base64: List[str]
    task_descriptions: List[str]
    subgoal_histories: Optional[List[List[str]]] = None

class PlanBatchResponse(BaseModel):
    pred_texts: List[str]

def load_model(model_path: str):
    global model, processor
    print(f"Loading model from {model_path} on {device}...")
    
    # model = Qwen2_5_VLForConditionalGeneration.from_pretrained(
    #     model_path,
    #     torch_dtype=torch.bfloat16,
    #     device_map=device,
    #     trust_remote_code=True
    # )
    
    processor = Qwen2_5_VLProcessor.from_pretrained(
        model_path,
        trust_remote_code=True
    )
    
    # model.eval()
    model = LLM(model=model_path, trust_remote_code=True,gpu_memory_utilization=0.3,tensor_parallel_size=1)

    print("Model loaded successfully!")

@app.post("/plan", response_model=PlanResponse)
async def plan(request: PlanRequest):
    try:
        # Decode image
        image_data = base64.b64decode(request.image_base64)
        image = Image.open(io.BytesIO(image_data)).convert("RGB")
        
        # Build prompt logic (same as original VLMPlanner)
        history_text = ""
        if request.subgoal_history:
            history_text = f" Completed subgoals: {', '.join(request.subgoal_history)}."
            
        prompt = (
            f"<image>You are a task planner. The current task is {request.task_description}.Please decompose the task and provide the next sub-goal, along with the expected image coordinates of the relevant objects."
        )
        
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image},
                    {"type": "text", "text": prompt}
                ]
            }
        ]
        
        text_prompt = processor.apply_chat_template(
            messages, 
            add_generation_prompt=True
        )
        inputs = {
            "prompt": text_prompt,
            "multi_modal_data": {
                "image": [image],
            },
        }
        sampling_params = SamplingParams(
            max_tokens=1024,
            temperature=0.0,
            top_p=1.0
        )
        outputs = model.generate(
            inputs,
            sampling_params=sampling_params
        )
        pred_text = outputs[0].outputs[0].text
        
        return PlanResponse(pred_text=pred_text)
        
    except Exception as e:
        print(f"Error processing request: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/plan_batch", response_model=PlanBatchResponse)
async def plan_batch(request: PlanBatchRequest):
    try:
        batch_size = len(request.images_base64)
        if batch_size == 0:
            return PlanBatchResponse(pred_texts=[])
        
        # Decode all images
        images = []
        for img_b64 in request.images_base64:
            image_data = base64.b64decode(img_b64)
            image = Image.open(io.BytesIO(image_data)).convert("RGB")
            images.append(image)
        
        # Build prompts for each item
        batch_inputs = []
        for i in range(batch_size):
            history_text = ""
            if request.subgoal_histories and i < len(request.subgoal_histories) and request.subgoal_histories[i]:
                history_text = f" Completed subgoals: {', '.join(request.subgoal_histories[i])}."
            
            task_desc = request.task_descriptions[i] if i < len(request.task_descriptions) else ""
            prompt = (
                f"<image>You are a task planner. The current task is {task_desc}.Please decompose the task and provide the next sub-goal, along with the expected image coordinates of the relevant objects."
            )
            
            messages = [
                {
                    "role": "user",
                    "content": [
                        {"type": "image", "image": images[i]},
                        {"type": "text", "text": prompt}
                    ]
                }
            ]
            
            text_prompt = processor.apply_chat_template(
                messages,
                add_generation_prompt=True
            )
            batch_inputs.append({
                "prompt": text_prompt,
                "multi_modal_data": {
                    "image": [images[i]],
                },
            })
        
        # Batch generate with vLLM
        sampling_params = SamplingParams(
            max_tokens=1024,
            temperature=0.0,
            top_p=1.0
        )
        outputs = model.generate(batch_inputs, sampling_params=sampling_params)
        
        # Extract pred_texts
        pred_texts = [output.outputs[0].text for output in outputs]
        
        return PlanBatchResponse(pred_texts=pred_texts)
        
    except Exception as e:
        print(f"Error processing batch request: {e}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_path", type=str, required=True, help="Path to Qwen2.5-VL model")
    parser.add_argument("--port", type=int, default=8000, help="Port to run server on")
    parser.add_argument("--host", type=str, default="0.0.0.0", help="Host to run server on")
    args = parser.parse_args()
    
    load_model(args.model_path)
    uvicorn.run(app, host=args.host, port=args.port)

