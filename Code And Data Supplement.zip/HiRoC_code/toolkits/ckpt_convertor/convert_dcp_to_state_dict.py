# Copyright 2025 The RLinf Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import argparse

import torch
from torch.distributed.checkpoint import FileSystemReader
from torch.distributed.checkpoint.default_planner import _EmptyStateDictLoadPlanner
from torch.distributed.checkpoint.state_dict_loader import _load_state_dict


def parse_args():
    parser = argparse.ArgumentParser(
        description="Convert DCP checkpoint to state_dict checkpoint"
    )
    parser.add_argument(
        "--dcp_path",
        type=str,
        required=True,
        help="Path to the DCP checkpoint directory",
    )
    parser.add_argument(
        "--output_path",
        type=str,
        required=True,
        help="Path to save the converted state_dict checkpoint",
    )
    return parser.parse_args()


def load_model_state_dict_from_dcp(dcp_path: str) -> dict:
    state_dict = {}
    try:
        planner = _EmptyStateDictLoadPlanner(keys={"model"})
    except TypeError as exc:
        raise RuntimeError(
            "This PyTorch version does not support selective DCP loading. "
            "Use a large TMPDIR with the old conversion path or upgrade PyTorch."
        ) from exc

    _load_state_dict(
        state_dict,
        storage_reader=FileSystemReader(dcp_path),
        planner=planner,
        no_dist=True,
    )
    if "model" not in state_dict:
        raise KeyError(f"No 'model' entry found in DCP checkpoint: {dcp_path}")
    return state_dict["model"]


if __name__ == "__main__":
    args = parse_args()
    model_state_dict = load_model_state_dict_from_dcp(args.dcp_path)
    torch.save(model_state_dict, args.output_path)

    print(
        f"Converted DCP checkpoint from {args.dcp_path} to state_dict at {args.output_path}"
    )
