#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Read numbers from multiple txt files, auto-detect whether values are duplicated
every 2 lines (A,A,B,B,...) and deduplicate if so, then plot by line order.

✅ 改进点：支持你“手动给每个 txt 命名”
- 方式1：在代码里用 NAMED_FILES = [(label, path), ...] 直接写死名字（推荐）
- 方式2：仍然用命令行 --files，并可选传 --labels 来覆盖显示名

Usage examples:
  # 推荐：你只改 NAMED_FILES，然后直接运行
  python plot_txt_numbers.py

  # 仍想用命令行传文件
  python plot_txt_numbers.py --files a.txt b.txt c.txt

  # 命令行传文件 + 自定义 legend 名称
  python plot_txt_numbers.py --files a.txt b.txt c.txt --labels seed0 seed42 baseline

  # 子图模式
  python plot_txt_numbers.py --mode subplots

  # 保存图片
  python plot_txt_numbers.py --save out.png
"""

import argparse
import re
from pathlib import Path
import matplotlib.pyplot as plt


# =========================
# ✅ 你在这里手动命名（最推荐）
# =========================
NAMED_FILES = [
    ("seed=0", "a.txt"),
    ("seed=42", "b.txt"),
    ("baseline(no-dup)", "c.txt"),
]
# 如果你想完全用命令行 --files，就把上面保留也没关系；
# 命令行传了 --files 时，会自动优先用命令行。


FLOAT_RE = re.compile(r"[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?")


def extract_first_float(line: str):
    """Return first float in a line, or None if not found."""
    m = FLOAT_RE.search(line)
    if not m:
        return None
    try:
        return float(m.group(0))
    except ValueError:
        return None


def load_txt_auto(path: str, check_k: int = 10, majority: float = 0.8, verbose: bool = True):
    """
    Read floats from txt.
    Auto-detect "two-line duplication": v0==v1, v2==v3, ...
    If detected (>= majority of first check_k pairs match), return values[::2].
    Otherwise return full values.
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {path}")

    values = []
    with p.open("r", encoding="utf-8", errors="ignore") as f:
        for raw in f:
            s = raw.strip()
            if not s:
                continue
            v = extract_first_float(s)
            if v is None:
                continue
            values.append(v)

    if len(values) < 2:
        if verbose:
            print(f"[auto] {path}: only {len(values)} value(s), no dedup")
        return values

    check_pairs = min(check_k, len(values) // 2)
    if check_pairs == 0:
        if verbose:
            print(f"[auto] {path}: not enough pairs, no dedup")
        return values

    pair_cnt = 0
    for i in range(check_pairs):
        if values[2 * i] == values[2 * i + 1]:
            pair_cnt += 1

    is_dup = pair_cnt >= majority * check_pairs

    if verbose:
        ratio = pair_cnt / check_pairs
        if is_dup:
            print(f"[auto] {path}: detected 2-line duplication ({pair_cnt}/{check_pairs}={ratio:.2f}), dedup applied")
        else:
            print(f"[auto] {path}: no duplication ({pair_cnt}/{check_pairs}={ratio:.2f}), keep all")

    return values[::2] if is_dup else values


def build_named_files(args):
    """
    优先级：
    1) 如果命令行传了 --files：使用命令行文件；若同时传了 --labels，就用 labels 覆盖图例名
    2) 否则：使用代码里写死的 NAMED_FILES
    """
    if args.files:
        files = args.files
        if args.labels:
            if len(args.labels) != len(files):
                raise ValueError(f"--labels count ({len(args.labels)}) must match --files count ({len(files)})")
            return list(zip(args.labels, files))
        else:
            # 默认用文件名作为 label
            return [(Path(p).name, p) for p in files]

    # 没传 --files，就用代码里的 NAMED_FILES
    return NAMED_FILES


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--files", nargs="+", default=None, help="txt files, e.g. a.txt b.txt c.txt")
    ap.add_argument("--labels", nargs="+", default=None, help="legend labels, e.g. seed0 seed42 baseline")
    ap.add_argument("--mode", choices=["same", "subplots"], default="same",
                    help="same: all curves in one plot; subplots: one file per subplot")
    ap.add_argument("--check_k", type=int, default=10, help="how many pairs to check for duplication detection")
    ap.add_argument("--majority", type=float, default=0.8, help="majority threshold for duplication detection")
    ap.add_argument("--no_verbose", action="store_true", help="suppress auto-detection logs")
    ap.add_argument("--save", default=None, help="save figure path (png/pdf/etc), e.g. out.png")
    args = ap.parse_args()

    verbose = not args.no_verbose

    named_files = build_named_files(args)

    series = []
    for label, fpath in named_files:
        y = load_txt_auto(fpath, check_k=args.check_k, majority=args.majority, verbose=verbose)
        if len(y) == 0:
            print(f"[warn] {fpath}: no numeric values extracted")
        series.append((label, fpath, y))

    if args.mode == "same":
        plt.figure(figsize=(9, 4))
        for label, _path, y in series:
            plt.plot(y, label=label)
        plt.xlabel("Step")
        plt.ylabel("succese rate")
        plt.title("hrc")
        plt.grid(True)
        plt.legend()
        plt.tight_layout()
    else:
        n = len(series)
        fig, axes = plt.subplots(n, 1, figsize=(9, max(3, 2.6 * n)), sharex=True)
        if n == 1:
            axes = [axes]
        for ax, (label, _path, y) in zip(axes, series):
            ax.plot(y, label=label)
            ax.set_title(label)
            ax.grid(True)
            ax.legend()
        axes[-1].set_xlabel("Step (line index)")
        fig.suptitle("hrc", y=1.02)
        plt.tight_layout()

    if args.save:
        out = Path(args.save)
        out.parent.mkdir(parents=True, exist_ok=True)
        plt.savefig(out, dpi=200, bbox_inches="tight")
        print(f"[ok] saved figure to: {out}")

    plt.show()


if __name__ == "__main__":
    main()
